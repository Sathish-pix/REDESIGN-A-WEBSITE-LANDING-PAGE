# Website-Landing-page-design

 This is a simple nature-themed website landing page design using HTML and CSS is a creative and enjoyable project. 
 This type of design often aims to evoke the beauty and serenity of the natural world 
 
![website image](https://github.com/Satyam354/Website-Landing-page-design/assets/83005998/a104de27-2bf4-40d0-9e27-ddcb632f6132)

